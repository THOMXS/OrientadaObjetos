package Modelo;

public class Genero {
	private String nomeGenero;
	public Genero() {
		
	}

	public Genero(String name) {
		nomeGenero = name;
	}

	public void setNomeGenero(String name) {
		nomeGenero = name;
	}

	public String getNomeGenero() {
		return nomeGenero;
	}

}
