package Modelo;

public class Ator {
	private String nomeAtor;

	public Ator(String name) {
		nomeAtor = name;
	}

	public void setNomeAtor(String name) {
		nomeAtor = name;
	}

	public String getNomeAtor() {
		return nomeAtor;
	}

}
