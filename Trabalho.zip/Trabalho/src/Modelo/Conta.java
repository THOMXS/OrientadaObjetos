package Modelo;

public class Conta {
	private String nomePlano;
	
		public Conta(String name) {
			nomePlano = name;
		}
		public void setNomePlano(String name) {
			nomePlano = name;
		}
		
		public String getNomePlano() {
			return nomePlano;
		}
					
	}