package Modelo;

public class Streaming {
	private String NomeStream;

	public Streaming(String name) {
		NomeStream = name;

	}

	public void setNomeStream(String name) {
		NomeStream = name;
	}

	public String getNomeStream() {
		return NomeStream;
	}

}