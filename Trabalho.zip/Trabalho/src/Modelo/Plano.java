package Modelo;

public class Plano {
	private String nomePlano;

	public Plano(String name) {
		nomePlano = name;
	}

	public void setNomePlano(String name) {
		nomePlano = name;
	}

	public String getNomePlano() {
		return nomePlano;
	}

}