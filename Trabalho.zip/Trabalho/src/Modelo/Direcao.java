package Modelo;

public class Direcao {
	private String nomeDirecao;

	public Direcao(String name) {
		nomeDirecao = name;
	}

	public void setNomeDirecao(String name) {
		nomeDirecao = name;
	}

	public String getNomeDirecao() {
		return nomeDirecao;
	}
}
