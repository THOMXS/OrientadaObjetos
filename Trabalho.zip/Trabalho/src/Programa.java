
import Controle.ProgramaControle;

public class Programa {

	public static void main(String[] args) {

		ProgramaControle programaControle = new ProgramaControle();
	}

}
